
#include <xc.h>
#include "main.h"
#include "clcd.h"
extern unsigned char sw_flag1,sw_flag2,sec,clear,flag,set_fun_flag,count,alarm_flag,once;
extern int loop;
extern unsigned char duration[3][11],time[9],A_P[3];
void __interrupt() isr(void)
{
	static unsigned long int isr_count,weekly=1;
     
	if (TMR0IF)
	{
		TMR0 = TMR0 + 8;

		if (isr_count++ == 20000)
		{
			isr_count = 0;
            for(int i=0;i<count;i++)
            {
                if(time[0]==duration[i][0] && time[0]==duration[i][1] && time[3]==duration[i][3] && time[4]==duration[i][4])
                {
                    if(A_P[0]==duration[i][6] && duration[i][9]=='O' && once && time[6]=='0' && time[7]=='0' )
                    {
                        if(count==1)
                            count=0;
                        alarm_flag=1;
                        once=0;
                        CLEAR_DISP_SCREEN;
                    }
                    else if(A_P[0]==duration[i][6] && duration[i][9]=='D' && time[6]=='0' && time[7]=='0')
                    {
                        CLEAR_DISP_SCREEN;
                        alarm_flag=1;
                    }
                    else if(A_P[0]==duration[i][6] && duration[i][9]=='W' && time[6]=='0' && time[7]=='0')
                    {
                        if(weekly++==14)
                        {
                            CLEAR_DISP_SCREEN;
                            alarm_flag=1;
                            weekly=1;
                        }   
                    }
                }
            }
            

            if(sec++<7)
            {
                if(flag && sec==4)
                {
                    CLEAR_DISP_SCREEN;
                    clear=0;
                    sw_flag1=0;
                    sw_flag2=0;
                    if(set_fun_flag==0)
                        flag=0;
                    sec=0;
                }
                else if(sec==5)
                {
                    loop++;
                    CLEAR_DISP_SCREEN;
                }
            }
            else
            {
                CLEAR_DISP_SCREEN;
                sec=0;
            }
        }
		TMR0IF = 0;
	}
    
}