/*
 * File:   main.c
 * Author: Prathamesh Patil
 *
 * Created on 14 November, 2024, 4:08 PM
 */


#include <xc.h>

void main(void) {
    return;
}
