/*
    Name : Vivek Bharat Patil
    Date : 25/10/2024
    Description : Digital Timer(Alarm Clock) 
*/
#include <xc.h>
#include "clcd.h"
#include "ds1307.h"
#include "i2c.h"
#include "matrix_keypad.h"
#include "timer0.h"
#include <string.h>

unsigned char clock_reg[3];
unsigned char calender_reg[4];
unsigned char time[9];
unsigned char date[11];
unsigned char A_P[3];

unsigned char alarm_flag;           //declaration of all variables

// MAIN FUNCTION
unsigned char key,sw_flag1,sw_flag2,sw_flag3,sw_flag4,flag,clear,sec;

// configure FUNCTION
unsigned char flag1,set_fun_flag,funct_flag;

// set_clock FUNCTION
unsigned char set_flag,set_T_D_flag,funct_set_flag,set_clear;

//set time function 
unsigned char set_time_clear,h=1,m,s,field_change;

int delay,loop=-1,view_index; //Delay for Both time and date //

//set date function 
unsigned char set_date_clear,yr=1,mon=1,d=1;

// SET_VIEW_EVENTS
unsigned char clear_disp,event_flag,S_V_event_flag;

unsigned char sec_flag,once=1; //Delay for Both set and view events //

//SET EVENTS
unsigned char event_clear;
unsigned char duration[3][11]={"#"},Hr,Mi,ind,dur_flag,count; // To store  the events


void display_time(void)            // display function to display the time
{

	if (clock_reg[0] & 0x40)
	{
		if (clock_reg[0] & 0x20)
            strcpy(A_P,"PM");
		else
            strcpy(A_P,"AM");
	}
}

static void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);           // this function gives the time
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
    if(sec_flag!=0)
    {
        time[5]='\0';
    }
    else
    {
        time[5] = ':';
        time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
        time[7] = '0' + (clock_reg[2] & 0x0F);
        time[8] = '\0';
    }
}

static void get_date(void)
{
	calender_reg[0] = read_ds1307(YEAR_ADDR);
	calender_reg[1] = read_ds1307(MONTH_ADDR);
	calender_reg[2] = read_ds1307(DATE_ADDR);                // this function give the date
	calender_reg[3] = read_ds1307(DAY_ADDR);

    date[0] = '0' + ((calender_reg[2] >> 4) & 0x0F);
	date[1] = '0' + (calender_reg[2] & 0x0F);
    date[2] = '/';
    date[3] = '0' + ((calender_reg[1] >> 4) & 0x0F);
	date[4] = '0' + (calender_reg[1] & 0x0F);
    date[5] = '/';
	date[6] = '2';
	date[7] = '0';
	date[8] = '0' + ((calender_reg[0] >> 4) & 0x0F);
	date[9] = '0' + (calender_reg[0] & 0x0F);
	date[10] = '\0';
}

void init_config(void)                            // initial configurations
{
    PEIE = 1;
	/* Clear old content */
	

	/* Config PORTB as digital */
	ADCON1 = 0x0F;

	init_timer0();

	GIE = 1;
	init_clcd();           // configuration of CLCD
	init_i2c();            // configuration of I2C
	init_ds1307();        // configuration of RTC
    init_matrix_keypad();  // configuration of matrix keypad

}

void view_event() // function defination
{
    if(event_clear==0)           
    {
        CLEAR_DISP_SCREEN;
        get_time();
        event_clear++;
    }
    
    clcd_print("# T - ", LINE1(0));           // display the characters on the CLCD
    clcd_print(time, LINE1(6));
    if (clock_reg[0] & 0x40)
    {
        if (clock_reg[0] & 0x20)
        {
            clcd_print("PM", LINE1(12));
        }
        else
        {
            clcd_print("AM", LINE1(12));
        }
    }
    clcd_putch('*', LINE1(15));
    
    if(count==0)                         // if count =0 No event is there
    {
        clcd_print("No Event Record", LINE2(1));
    }
    else
    {
        clcd_putch('0'+view_index,LINE2(0));
        clcd_print("D - ", LINE2(2));
        clcd_print(duration[view_index],LINE2(6));
    }
    if(sw_flag4 > 80)                   // for return to back menu
    {
        event_clear=0,view_index=0;
        clear_disp=0,S_V_event_flag=0,funct_set_flag=1,event_flag=1,sec_flag=0;
    }
    else if((sw_flag1 > 0 && sw_flag1 < 70 ))        // Scrolling up or down
    {
        if(view_index>0)
            view_index--;
    }
    else if((sw_flag2 > 0 && sw_flag2 < 70 ))
    {
        if(view_index<count-1)
            view_index++;
    }
    else if((sw_flag3 > 0 && sw_flag3 < 70 ))              // Eraseing the Events
    {
        count=0;
    }
}
void set_event()           /
{
    if(event_clear==0)
    {
        CLEAR_DISP_SCREEN;
        get_time();
        event_clear++;
    }
    
    clcd_print("TIME: ", LINE1(0));
    clcd_print(time, LINE1(6));
    if (clock_reg[0] & 0x40)
    {
        if (clock_reg[0] & 0x20)
        {
            clcd_print("PM", LINE1(12));
        }
        else
        {
            clcd_print("AM", LINE1(12));
        }
    }
    clcd_putch('*', LINE1(15));

    clcd_print("DUR - ", LINE2(0));
    
    clcd_putch(':', LINE2(8));
    
    if(sw_flag2 > 80)                   // return back to previous menu
    {
        event_clear=0,field_change=0,delay=0;
        clear_disp=0,S_V_event_flag=0,funct_set_flag=1,event_flag=1,sec_flag=0;
    }
    else if((sw_flag1 > 0 && sw_flag1 < 70 ))              // increamenting the count values of Hours,MInutes,Seconds
    {
        if(field_change == 0 && Hr++==12)
        {
            Hr=1;
        }
        else if(field_change == 1 && Mi++==59)
        {
            Mi=0;
        }
        else if(field_change == 2)
        {
            ind=!ind;
        }
        else if(field_change == 3 && dur_flag++==2)
            dur_flag=0;
    }
    else if((sw_flag3 > 0 && sw_flag3 < 70 ))               // Changing the field
    {
        if(field_change++ == 3)
            field_change=0;
    }
    else if((sw_flag4 > 0 && sw_flag4<70 ))       //For saving the data in the array
    {
        if(count<3)
        {
            duration[count][0]=Hr/10 + '0';
            duration[count][1]=Hr%10 + '0';
            duration[count][2]=':';
            duration[count][3]=Mi/10 + '0';
            duration[count][4]=Mi%10 + '0';
            duration[count][5]=' ';
            if(ind)
                duration[count][6]='P';
            else
                duration[count][6]='A';
            duration[count][7]='M';
            duration[count][8]=' ';
            if(dur_flag==0)
            {
                once=1;
                duration[count][9]='O';
            }
            else if(dur_flag==1)
                duration[count][9]='D';
            else if(dur_flag==2)
                duration[count][9]='W';
            duration[count++][10]='\0';
        }
    }
    
    if(delay++ < 150 )                 //Blink the Specific Field
    {
        clcd_putch('0'+(Hr/10), LINE2(6));
        clcd_putch('0'+(Hr%10), LINE2(7));
        
        clcd_putch('0'+(Mi/10), LINE2(9));
        clcd_putch('0'+(Mi%10), LINE2(10));
        if(ind)
            clcd_print("PM",LINE2(12));
        else
            clcd_print("AM",LINE2(12));
        
        if(dur_flag==0)
            clcd_putch('O',LINE2(15));
        else if(dur_flag==1)
            clcd_putch('D',LINE2(15));
        else if(dur_flag==2)
            clcd_putch('W',LINE2(15));
    }
    else if(delay++ < 300)
    {
        if(field_change==0)
        {
            clcd_putch(' ', LINE2(6));
            clcd_putch(' ', LINE2(7));

            clcd_putch('0'+(Mi/10), LINE2(9));
            clcd_putch('0'+(Mi%10), LINE2(10));
            if(ind)
                clcd_print("PM",LINE2(12));
            else
                clcd_print("AM",LINE2(12));

            if(dur_flag==0)
                clcd_putch('O',LINE2(15));
            else if(dur_flag==1)
                clcd_putch('D',LINE2(15));
            else if(dur_flag==2)
                clcd_putch('W',LINE2(15));
        }
        else if(field_change==1)
        {
            clcd_putch('0'+(Hr/10), LINE2(6));
            clcd_putch('0'+(Hr%10), LINE2(7));

            clcd_putch(' ', LINE2(9));
            clcd_putch(' ', LINE2(10));
            if(ind)
                clcd_print("PM",LINE2(12));
            else
                clcd_print("AM",LINE2(12));
            
            if(dur_flag==0)
                clcd_putch('O',LINE2(15));
            else if(dur_flag==1)
                clcd_putch('D',LINE2(15));
            else if(dur_flag==2)
                clcd_putch('W',LINE2(15));
        }
        else if(field_change==2)
        {
            clcd_putch('0'+(Hr/10), LINE2(6));
            clcd_putch('0'+(Hr%10), LINE2(7));

            clcd_putch('0'+(Mi/10), LINE2(9));
            clcd_putch('0'+(Mi%10), LINE2(10));
           
            clcd_print("  ",LINE2(12));
            
            if(dur_flag==0)
                clcd_putch('O',LINE2(15));
            else if(dur_flag==1)
                clcd_putch('D',LINE2(15));
            else if(dur_flag==2)
                clcd_putch('W',LINE2(15));
        }
        else if(field_change==3)
        {
            clcd_putch('0'+(Hr/10), LINE2(6));
            clcd_putch('0'+(Hr%10), LINE2(7));

            clcd_putch('0'+(Mi/10), LINE2(9));
            clcd_putch('0'+(Mi%10), LINE2(10));
            if(ind)
                clcd_print("PM",LINE2(12));
            else
                clcd_print("AM",LINE2(12));
            
            clcd_putch(' ',LINE2(15));  
        }
    }
    else
        delay=0;
        
}
set_view_event()
{
    if(clear_disp==0)
    {
        CLEAR_DISP_SCREEN;
        sw_flag1=0;
        clear_disp++;
    }
    
    if(sw_flag2 > 80 && S_V_event_flag==0 )                // return back to previous menu
    {
        clear_disp=0,flag1=1,funct_set_flag=1,set_fun_flag=0,clear=0;
    }
    else if((sw_flag1 > 80 && funct_set_flag ) || S_V_event_flag==1)
    {
        S_V_event_flag=1;
        sec_flag=1;                             // entering into the first menu
        set_event();
    }
    else if((sw_flag1 > 80 && !funct_set_flag ) || S_V_event_flag==2)
    {
        S_V_event_flag=2;
        sec_flag=1;                 // entering into the second menu
        view_event();
    }
    else if(event_flag==1)
    {
        clcd_print("->SET EVENT", LINE1(0));
        clcd_print("  VIEW EVENT", LINE2(0));       //displaying the menu on the CLCD 
        funct_set_flag=1;
       
    }
    else if(event_flag==2)
    {
        clcd_print("  SET EVENT", LINE1(0));
        clcd_print("->VIEW EVENT", LINE2(0));
        funct_set_flag=0;
    }
}
void set_time()
{
    if(set_time_clear==0)
    {
        if (clock_reg[0] & 0x40)
        {
            h=(((clock_reg[0] >> 4) & 0x01)*10)+(clock_reg[0] & 0x0F);
        }
        else
        {
            h=(((clock_reg[0] >> 4) & 0x03)*10)+(clock_reg[0] & 0x0F);
        }
        m=(((clock_reg[1]>>4 & 0x0F)*10) + clock_reg[1] & 0x0F);
        s=(((clock_reg[2]>>4 & 0x0F)*10) + clock_reg[2] & 0x0F);// reading the value from the array into the Hours,minutes, second variables
                
        CLEAR_DISP_SCREEN;
        sw_flag1=0;
        set_time_clear++;
    }
    
    clcd_print("HH:MM:SS", LINE1(4));
    clcd_putch(':', LINE2(6));
    clcd_putch(':', LINE2(9));
    
    
    if(sw_flag2 > 80)         // returning back to the previous menu
    {
        set_time_clear=0,field_change=0,delay=0;
        set_flag=1,set_T_D_flag=0,funct_set_flag=1,set_clear=0;
    }
    else if((sw_flag1 > 0 && sw_flag1 < 70 ))            // increamenting the hours,minutes,second value
    {
        if(field_change==0 && h++==12)
            h=1;
        else if(field_change==1 && m++==59)
            m=0;
        else if(field_change==2 && s++==59)
            s=0;
        delay=0;
    }
    else if((sw_flag3 > 0 && sw_flag3 < 70 ))           // changing the field
    {
        if(field_change++ == 2)
            field_change=0;
    }
    else if((sw_flag4 > 0 && sw_flag4 < 70 ))                 // writing the changed into the RTC address(Hrs,Min,Sec)
    {
        h=((h/10<<4)| (h%10));
        m=((m/10<<4)| (m%10));
        s=((s/10<<4)| (s%10));
        write_ds1307(HOUR_ADDR,h);
        write_ds1307(MIN_ADDR,m);
        write_ds1307(SEC_ADDR,s);
    }
    
    if(delay++ < 150 )             // Blink the fields
    {
        clcd_putch('0'+(h/10), LINE2(4));
        clcd_putch('0'+(h%10), LINE2(5));
        clcd_putch('0'+(m/10), LINE2(7));
        clcd_putch('0'+(m%10), LINE2(8));
        clcd_putch('0'+(s/10), LINE2(10));
        clcd_putch('0'+(s%10), LINE2(11));
    }
    else if(delay++ < 300)
    {
        if(field_change==0)
        {
            clcd_putch(' ', LINE2(4));
            clcd_putch(' ', LINE2(5));
            clcd_putch('0'+(m/10), LINE2(7));
            clcd_putch('0'+(m%10), LINE2(8));
            clcd_putch('0'+(s/10), LINE2(10));
            clcd_putch('0'+(s%10), LINE2(11));
            
        }
        else if(field_change==1)
        {
            clcd_putch('0'+(h/10), LINE2(4));
            clcd_putch('0'+(h%10), LINE2(5));
            clcd_putch(' ', LINE2(7));
            clcd_putch(' ', LINE2(8));
            clcd_putch('0'+(s/10), LINE2(10));
            clcd_putch('0'+(s%10), LINE2(11));
        }
        else if(field_change==2)
        {
            clcd_putch('0'+(h/10), LINE2(4));
            clcd_putch('0'+(h%10), LINE2(5));
            clcd_putch('0'+(m/10), LINE2(7));
            clcd_putch('0'+(m%10), LINE2(8));
            clcd_putch(' ', LINE2(10));
            clcd_putch(' ', LINE2(11));
        }   
    }
    else
        delay=0;
}

void set_date()
{
    if(set_date_clear==0)
    {
        yr=(((calender_reg[0]>>4 & 0x0F)*10) + calender_reg[0] & 0x0F);
        mon=(((calender_reg[1]>>4 & 0x0F)*10) + calender_reg[1] & 0x0F);
        d=(((calender_reg[2]>>4 & 0x0F)*10) + calender_reg[2] & 0x0F); // reading the Date from the array
                
        CLEAR_DISP_SCREEN;
        sw_flag1=0;
        set_date_clear++;
    }
    
    clcd_print("DD:MM:YY", LINE1(4));
    clcd_putch(':', LINE2(6));
    clcd_putch(':', LINE2(9));
    
    
    if(sw_flag2 > 80)                // return to preivous  menu
    {
        set_date_clear=0,field_change=0,delay=0;
        set_flag=1,set_T_D_flag=0,funct_set_flag=1,set_clear=0;
    }
    else if((sw_flag1 > 0 && sw_flag1 < 70 ))   // increamenting the dates
    { 
        if(field_change==0 && ((mon==2 && d++==28) || (mon!=2 && d++==31)))
            d=1;
        else if(field_change==1 && mon++==12)
            mon=1;
        else if(field_change==2 && yr++==99)
            yr=1;
        delay=0;
    }
    else if((sw_flag3 > 0 && sw_flag3 < 70 ))      // changing the field
    {
        if(field_change++ == 2)
            field_change=0;
    }
    else if((sw_flag4 > 0 && sw_flag4 < 70 ))  // writing the changed data into the RTC Address
    {
        yr=((yr/10<<4)| (yr%10));
        mon=((mon/10<<4)| (mon%10));
        d=((d/10<<4)| (d%10));
        write_ds1307(YEAR_ADDR,yr);
        write_ds1307(MONTH_ADDR,mon);
        write_ds1307(DATE_ADDR,d);
    }
    
    if(delay++ < 150 )               // Blink the fileds
    {
        clcd_putch('0'+(d/10), LINE2(4));
        clcd_putch('0'+(d%10), LINE2(5));
        clcd_putch('0'+(mon/10), LINE2(7));
        clcd_putch('0'+(mon%10), LINE2(8));
        clcd_putch('0'+(yr/10), LINE2(10));
        clcd_putch('0'+(yr%10), LINE2(11));
    }
    else if(delay++ < 300)
    {
        if(field_change==0)
        {
            clcd_putch(' ', LINE2(4));
            clcd_putch(' ', LINE2(5));
            clcd_putch('0'+(mon/10), LINE2(7));
            clcd_putch('0'+(mon%10), LINE2(8));
            clcd_putch('0'+(yr/10), LINE2(10));
            clcd_putch('0'+(yr%10), LINE2(11));
            
        }
        else if(field_change==1)
        {
            clcd_putch('0'+(d/10), LINE2(4));
            clcd_putch('0'+(d%10), LINE2(5));
            clcd_putch(' ', LINE2(7));
            clcd_putch(' ', LINE2(8));
            clcd_putch('0'+(yr/10), LINE2(10));
            clcd_putch('0'+(yr%10), LINE2(11));
        }
        else if(field_change==2)
        {
            clcd_putch('0'+(d/10), LINE2(4));
            clcd_putch('0'+(d%10), LINE2(5));
            clcd_putch('0'+(mon/10), LINE2(7));
            clcd_putch('0'+(mon%10), LINE2(8));
            clcd_putch(' ', LINE2(10));
            clcd_putch(' ', LINE2(11));
        }   
    }
    else
        delay=0;
}
void set_clock()
{
    if(set_clear==0)
    {
        CLEAR_DISP_SCREEN;
        set_clear++;
        sw_flag1=0;
    }
    
    if(sw_flag2 > 80 && set_T_D_flag==0 )      // return into the previous menu
    {
        set_clear=0,flag1=1,funct_set_flag=1,set_fun_flag=0;
    }
    else if((sw_flag1 > 80 && funct_set_flag ) || set_T_D_flag==1) // enetering into the First Menu
    {
        set_T_D_flag=1;
        set_time();
    }
    else if((sw_flag1 > 80 && !funct_set_flag ) || set_T_D_flag==2) // enetering into the Second Menu
    {
        set_T_D_flag=2;
        set_date();
    }
    else if(set_flag==1)
    {
        clcd_print("->SET TIME", LINE1(0));
        clcd_print("  SET DATE", LINE2(0));
        funct_set_flag=1;
       
    }
    else if(set_flag==2)
    {
        clcd_print("  SET TIME", LINE1(0));
        clcd_print("->SET DATE", LINE2(0));
        funct_set_flag=0;
    }  
}

void config_mode()
{
    if(clear==0 )
    {
        CLEAR_DISP_SCREEN;
        sec=0;
        clear++;
    }
    if(sw_flag1 > 80 && funct_flag || set_fun_flag==1) // enetering into the First Menu
    {
       set_fun_flag=1;
       set_view_event();   
    }
    else if((sw_flag1 > 80 && !funct_flag)|| set_fun_flag==2)// enetering into the Second Menu
    {    
        set_fun_flag=2;
        set_clock();  
    } 
    else if(flag1)
    {
        clcd_print("->SET/VIEW EVENT", LINE1(0));    // displaying the menu characters on the CLCD 
        clcd_print("  SET TIME/DATE", LINE2(0));
        flag1=1;
        funct_flag=1; 
    }
    else if(flag1==0)
    {
        clcd_print("  SET/VIEW EVENT", LINE1(0));
        clcd_print("->SET TIME/DATE", LINE2(0));
        funct_flag=0;
        flag1=0;
    }        
}
void main(void)
{
	init_config();
    // BUZZER 
    TRISE0=0;    // Buzzer configurations
    RE0=0;
	while (1)
	{
        get_time();
        get_date();
        display_time();
        key=read_switches(LEVEL_CHANGE);     // reading the switches value
        if(alarm_flag && key!=MK_SW3)   // when alarm is On then Press Switch 3 to off it
        {
            clcd_print(" *** ALARM *** ",LINE1(0));
            clcd_print("PRESS SW3 TO OFF",LINE2(0));
            RE0=1;
        }
        else if(key==MK_SW3)  //OFF the Alarm 
        {
            CLEAR_DISP_SCREEN;
            alarm_flag=0;
            RE0=0;
        }
        else
        {
            if(key==MK_SW1)      // reading the switche 1 value
            {
                flag1=1;
                set_flag=1;
                sec=0;
                event_flag=1;
                sw_flag1++;
            }
            else if(key==MK_SW2)// reading the switche 2 value
            {   
                flag1=0;
                sec=0;
                set_flag=2;
                event_flag=2;
                sw_flag2++;
            }
            else if(key==MK_SW4)// reading the switche 3 value(actual matrix keypad switche 4)
            {
                sw_flag3++;
            }
            else if(key==MK_SW7)// reading the switche 3 value(actual matrix keypad switche 7)
            {
                sw_flag4++;
            }
            else if( (sw_flag1 > 0 &&  sw_flag1 < 70 ) || flag)
            {
                flag=1;
                config_mode();
                sw_flag1=0;
                sw_flag2=0;            // for entering into the Main menu
                sw_flag3=0;
                sw_flag4=0;
            }
            else
            {
                if(sec<5)
                {
                    clcd_print(A_P, LINE2(14));
                    clcd_print("DATE ", LINE1(0));
                    clcd_print(date, LINE1(5));      // after every five second the events are displayed on the CLCD
                    clcd_print("TIME ", LINE2(0));
                    clcd_print(time, LINE2(5));
                }
                else
                {
                    clcd_print("TIME ", LINE1(0));
                    clcd_print(time, LINE1(5));
                    clcd_print(A_P, LINE1(14));
                    clcd_print("EVENT ", LINE2(0));
                    if(!count)
                    {
                        clcd_print("--:-- -- -", LINE2(6));    // Count=0 no events displayed 
                        loop=-1;
                    }
                    else
                    {
                        if(loop<count)
                            clcd_print(duration[loop],LINE2(6));  //To displayed every event back to back after every 5 sec
                        else
                            loop=0;


                    }
                }
            }
        } 
	}
}